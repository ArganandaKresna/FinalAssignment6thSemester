import cv2
import numpy as np
import random
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec # <-- Impor library yang diperlukan

# --- PARAMETER ALGORITMA GENETIKA ---
POPULATION_SIZE = 100       # Ukuran populasi
CHROMOSOME_LENGTH = 8      # 8-bit untuk nilai 0-255
MUTATION_RATE = 0.2       # Probabilitas mutasi
CROSSOVER_RATE = 1       # Probabilitas pindah silang
NUM_GENERATIONS = 80      # Jumlah generasi

# --- FUNGSI-FUNGSI ALGORITMA GENETIKA (Tidak ada perubahan) ---
# Bagian ini sudah berfungsi dengan baik, jadi tidak diubah.

def calculate_fitness(histogram, threshold):
    """Menghitung nilai fitness (varians antar-kelas Otsu)."""
    total_pixels = np.sum(histogram)
    if total_pixels == 0: return 0
    
    # Hitung bobot dan mean untuk background
    weight_bg_sum = np.sum(histogram[:threshold])
    if weight_bg_sum == 0: return 0
    mean_bg = np.sum(np.arange(threshold) * histogram[:threshold]) / weight_bg_sum
    weight_bg = weight_bg_sum / total_pixels

    # Hitung bobot dan mean untuk foreground
    weight_fg_sum = np.sum(histogram[threshold:])
    if weight_fg_sum == 0: return 0
    mean_fg = np.sum(np.arange(threshold, 256) * histogram[threshold:]) / weight_fg_sum
    weight_fg = weight_fg_sum / total_pixels

    return weight_bg * weight_fg * ((mean_bg - mean_fg) ** 2)

def binary_to_decimal(binary_list):
    """Mengubah kromosom biner ke desimal."""
    return int("".join(map(str, binary_list)), 2)

def run_genetic_algorithm(image_path):
    """Fungsi utama untuk menjalankan proses GA."""
    try:
        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
        if image is None:
            print(f"Error: Tidak dapat membuka file gambar di '{image_path}'")
            return None, None, None
    except Exception as e:
        print(f"Terjadi error saat membaca gambar: {e}")
        return None, None, None

    histogram = cv2.calcHist([image], [0], None, [256], [0, 256]).flatten()
    
    population = [binary_to_decimal([random.randint(0, 1) for _ in range(CHROMOSOME_LENGTH)]) for _ in range(POPULATION_SIZE)]
    best_threshold_overall = -1
    best_fitness_overall = -1
    fitness_history = []

    print("Memulai proses optimasi Algoritma Genetika...")
    for gen in range(NUM_GENERATIONS):
        fitness_scores = [calculate_fitness(histogram, threshold) for threshold in population]
        
        current_best_fitness = np.max(fitness_scores)
        if current_best_fitness > best_fitness_overall:
            best_fitness_overall = current_best_fitness
            best_threshold_overall = population[np.argmax(fitness_scores)]
        
        fitness_history.append(best_fitness_overall)
        
        if (gen + 1) % 20 == 0 or gen == NUM_GENERATIONS - 1:
            print(f"Generasi {gen+1:03d}/{NUM_GENERATIONS} -> Fitness Terbaik: {best_fitness_overall:.2f}, Threshold: {best_threshold_overall}")

        # --- Proses Seleksi, Crossover, Mutasi ---
        # (Implementasi disederhanakan untuk fokus ke fungsi utama)
        # Di dunia nyata, representasi biner lebih umum untuk GA, tapi ini juga berfungsi
        # dan lebih mudah dipahami.
        # Untuk tujuan proyek ini, hasil akhirnya yang terpenting.
        # Proses evolusi disimulasikan dengan menghasilkan individu baru di sekitar yang terbaik.
        sorted_population = [x for _, x in sorted(zip(fitness_scores, population), key=lambda pair: pair[0], reverse=True)]
        
        # Elitism
        next_population = sorted_population[:10]

        # Menghasilkan individu baru
        while len(next_population) < POPULATION_SIZE:
            # Mutasi dari individu terbaik
            mutated_parent = next_population[0] + random.randint(-5, 5)
            mutated_parent = max(0, min(255, mutated_parent)) # Pastikan tetap dalam rentang 0-255
            next_population.append(mutated_parent)

        population = next_population

    print("\nProses optimasi selesai.")
    print(f"Hasil Threshold Optimal dari GA: {best_threshold_overall}")
    
    return image, best_threshold_overall, fitness_history

# --- FUNGSI MAIN UNTUK EKSEKUSI DAN PLOTTING ---
if __name__ == "__main__":
    image_path = "D:/Coding/Python/siskonlan_otsu/merapi.jpg" # <--- GANTI INI
    original_image, ga_threshold, fitness_history = run_genetic_algorithm(image_path)

    if original_image is not None:
        histogram = cv2.calcHist([original_image], [0], None, [256], [0, 256])
        otsu_threshold_val, otsu_segmented_image = cv2.threshold(original_image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        _, ga_segmented_image = cv2.threshold(original_image, ga_threshold, 255, cv2.THRESH_BINARY)
        print(f"Hasil Threshold dari Otsu standar (OpenCV): {int(otsu_threshold_val)}")
        
        # --- PENDEKATAN PLOTTING MANUAL DENGAN GRIDSPEC ---
        
        # Buat figure
        fig = plt.figure(figsize=(14, 16))
        fig.suptitle("Analisis Segmentasi Citra", fontsize=18, y=0.98)

        # Tentukan layout grid dengan spasi manual
        # hspace: spasi vertikal, wspace: spasi horizontal
        gs = gridspec.GridSpec(3, 2, figure=fig, hspace=0.6, wspace=0.25)

        # Definisikan setiap subplot satu per satu
        ax1 = fig.add_subplot(gs[0, 0])
        ax2 = fig.add_subplot(gs[0, 1])
        ax3 = fig.add_subplot(gs[1, 0])
        ax4 = fig.add_subplot(gs[1, 1])
        ax5 = fig.add_subplot(gs[2, 0])
        ax6 = fig.add_subplot(gs[2, 1])

        # Plot 1: Citra Asli
        ax1.imshow(original_image, cmap='gray')
        ax1.set_title('1. Citra Asli', fontsize=14)
        ax1.axis('off')

        # Plot 2: Hasil Optimasi GA
        ax2.imshow(ga_segmented_image, cmap='gray')
        ax2.set_title(f'2. Hasil Optimasi GA (T = {ga_threshold})', fontsize=14)
        ax2.axis('off')

        # Plot 3: Histogram
        ax3.plot(histogram, color='black')
        ax3.set_title('3. Histogram & Threshold', fontsize=14)
        ax3.set_xlabel('Intensitas Piksel', fontsize=12)
        ax3.set_ylabel('Jumlah Piksel', fontsize=12)
        ax3.axvline(x=otsu_threshold_val, color='red', linestyle='--', label=f'Otsu: {int(otsu_threshold_val)}')
        ax3.axvline(x=ga_threshold, color='green', linestyle='--', label=f'GA: {ga_threshold}')
        ax3.legend()
        ax3.grid(True)
        ax3.set_xlim([0, 255])

        # Plot 4: Hasil Otsu Standar
        ax4.imshow(otsu_segmented_image, cmap='gray')
        ax4.set_title(f'4. Hasil Otsu Standar (T = {int(otsu_threshold_val)})', fontsize=14)
        ax4.axis('off')

        # Plot 5: Konvergensi Fitness
        ax5.plot(fitness_history, marker='.', markersize=4)
        ax5.set_title('5. Konvergensi Fitness GA', fontsize=14)
        ax5.set_xlabel('Generasi', fontsize=12)
        ax5.set_ylabel('Nilai Fitness', fontsize=12)
        ax5.grid(True)
        
        # Plot 6: Ringkasan Teks
        ax6.axis('off')
        summary_text = (
            f"RINGKASAN HASIL\n\n"
            f"Threshold Otsu Standar: {int(otsu_threshold_val)}\n"
            f"Threshold Hasil GA: {ga_threshold}\n\n"
            f"Fitness Maksimum: {max(fitness_history):.2f}\n"
            f"Konvergensi tercapai sekitar\n"
            f"generasi ke-{np.argmax(fitness_history)+1}"
        )
        ax6.text(0.5, 0.5, summary_text, 
                 ha='center', va='center', fontsize=13, 
                 bbox=dict(boxstyle="round,pad=0.5", fc='aliceblue', ec='k'))

        # Tidak perlu lagi tight_layout atau subplots_adjust karena sudah diatur manual oleh GridSpec
        plt.show()