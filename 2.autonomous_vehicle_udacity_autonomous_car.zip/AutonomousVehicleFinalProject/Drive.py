# Drive.py

import socketio
import eventlet
import numpy as np
from flask import Flask
from tensorflow.keras.models import load_model
import base64
from io import BytesIO
from PIL import Image
import cv2
import argparse
import os
import glob
from datetime import datetime

# Inisialisasi Flask dan SocketIO
sio = socketio.Server()
app = Flask(__name__)
script_dir = os.path.dirname(os.path.abspath(__file__))

# Class untuk mengelola logika mobil otonom
class AutonomousDriver:
    def __init__(self, model_path, speed_limit=30):
        """Inisialisasi driver otonom"""
        self.model = load_model(model_path)
        self.speed_limit = speed_limit
        self.log_data = []
        self.frame_count = 0
        print(f"Model loaded from: {model_path}")
        print(f"Speed limit set to: {speed_limit}")

    def preprocess_image(self, image):
        """
        Pra-pemrosesan gambar untuk prediksi model.
        HARUS SAMA PERSIS dengan pra-pemrosesan saat training.
        """
        image_array = np.asarray(image)
        # 1. Crop gambar
        image_array = image_array[60:135, :, :]
        # 2. Konversi ke YUV color space
        image_array = cv2.cvtColor(image_array, cv2.COLOR_RGB2YUV)
        # 3. Terapkan Gaussian Blur
        image_array = cv2.GaussianBlur(image_array, (3, 3), 0)
        # 4. Resize ke ukuran input model (66x200)
        image_array = cv2.resize(image_array, (200, 66))
        # 5. Normalisasi gambar
        image_array = image_array / 255.0
        return image_array
    
    def predict_steering(self, image):
        """Prediksi sudut kemudi dari gambar"""
        processed_image = self.preprocess_image(image)
        processed_image = np.expand_dims(processed_image, axis=0)
        steering_angle = float(self.model.predict(processed_image, verbose=0)[0][0])
        return steering_angle

    def calculate_throttle(self, speed, steering_angle):
        """Kalkulasi gas berdasarkan kecepatan dan sudut kemudi"""
        if abs(steering_angle) > 0.2:
            throttle = 0.2
        elif speed > self.speed_limit:
            throttle = 0.0  # Gas netral jika melebihi batas
        else:
            # Tetap berikan sedikit gas agar mobil terus maju
            throttle = 1.0 - (speed / self.speed_limit)
        return max(0.1, min(throttle, 1.0)) # Pastikan throttle antara 0.1 dan 1.0

    def log_telemetry(self, steering_angle, throttle, speed):
        """Mencatat data telemetri"""
        self.frame_count += 1
        log_entry = {
            'frame': self.frame_count, 'timestamp': datetime.now().isoformat(),
            'steering_angle': steering_angle, 'throttle': throttle, 'speed': speed
        }
        self.log_data.append(log_entry)
        if self.frame_count % 100 == 0:
            print(f"Frame {self.frame_count}: Steering={steering_angle:.3f}, Throttle={throttle:.3f}, Speed={speed:.1f}")

    def save_logs(self):
        """Menyimpan log ke file CSV"""
        import pandas as pd
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"autonomous_driving_log_{timestamp}.csv"
        df = pd.DataFrame(self.log_data)
        df.to_csv(filename, index=False)
        print(f"Driving logs saved to: {filename}")

# Variabel global untuk instance driver
driver = None

@sio.on('telemetry')
def telemetry(sid, data):
    """Menangani data telemetri dari simulator"""
    global driver
    if data and driver:
        speed = float(data["speed"])
        image = Image.open(BytesIO(base64.b64decode(data["image"])))
        try:
            steering_angle = driver.predict_steering(image)
            throttle = driver.calculate_throttle(speed, steering_angle)
            driver.log_telemetry(steering_angle, throttle, speed)
            send_control(steering_angle, throttle)
        except Exception as e:
            print(f"Error in telemetry processing: {e}")
            send_control(0, 0)
    else:
        sio.emit('manual', data={}, skip_sid=True)

@sio.on('connect')
def connect(sid, environ):
    """Menangani koneksi dari klien"""
    print("Connected to simulator")
    send_control(0, 0)

def send_control(steering_angle, throttle):
    """Mengirim perintah kontrol ke simulator"""
    sio.emit("steer", data={'steering_angle': str(steering_angle), 'throttle': str(throttle)}, skip_sid=True)

def find_available_models():
    """Mencari semua file model .h5"""
    print("Searching for available .h5 model files...")
    models = sorted(list(set(glob.glob(os.path.join(script_dir, '**', '*.h5'), recursive=True))))
    return models

def select_model():
    """Memungkinkan pengguna memilih model yang tersedia"""
    models = find_available_models()
    if not models:
        print("No .h5 model files found!")
        return None
    print(f"\nFound {len(models)} model file(s):\n" + "="*60)
    for i, model_path in enumerate(models, 1):
        rel_path = os.path.relpath(model_path, script_dir)
        print(f"{i:2d}. {rel_path}")
    print("=" * 60)
    while True:
        try:
            choice = input(f"Select a model (1-{len(models)}) or 'q' to quit: ").strip()
            if choice.lower() == 'q': return None
            model_idx = int(choice) - 1
            if 0 <= model_idx < len(models):
                return models[model_idx]
            else:
                print(f"Invalid selection.")
        except ValueError:
            print("Invalid input.")

def main():
    """Fungsi utama untuk menjalankan script"""
    global driver
    print("=" * 60 + "\nUDACITY AUTONOMOUS DRIVING SIMULATOR\n" + "=" * 60)
    
    selected_model_path = select_model()
    if selected_model_path is None: return

    parser = argparse.ArgumentParser(description='Remote Driving')
    parser.add_argument('--speed', type=int, default=30, help='Speed limit')
    parser.add_argument('--port', type=int, default=4567, help='Port number')
    args = parser.parse_args()

    try:
        driver = AutonomousDriver(selected_model_path, args.speed)
        print("\n✓ Model loaded successfully!")
        
        app_wrapped = socketio.Middleware(sio, app)
        print("\n" + "=" * 60 + "\nSERVER READY!\n" + "=" * 60)
        print("1. Open Udacity Self-Driving Car Simulator")
        print("2. Select 'Autonomous Mode'")
        print("3. Watch your car drive autonomously!\n" + "=" * 60)
        
        eventlet.wsgi.server(eventlet.listen(('', args.port)), app_wrapped)

    except KeyboardInterrupt:
        print("\n" + "=" * 60 + "\nSHUTTING DOWN...\n" + "=" * 60)
        if driver and driver.log_data: driver.save_logs()
        print("Server stopped.")
    except Exception as e:
        print(f"\nAn error occurred: {e}")

if __name__ == '__main__':
    main() 